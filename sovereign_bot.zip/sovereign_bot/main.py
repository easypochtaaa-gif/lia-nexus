import asyncio
import os
import sqlite3
from datetime import datetime
from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from anthropic import AsyncAnthropic

# --- CONFIGURATION ---
ADMIN_ID = 7915004877  # Architect Arthur
DB_PATH = "/data/lia_sovereign.db" if os.path.exists("/data") else "lia_sovereign.db"

# --- INITIALIZATION ---
bot = Bot(token=os.getenv('BOT_TOKEN'))
dp = Dispatcher()
anthropic_client = AsyncAnthropic(api_key=os.getenv('ANTHROPIC_API_KEY'))

# --- DATABASE SETUP ---
def init_db():
    os.makedirs(os.path.dirname(DB_PATH) or '.', exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            role TEXT DEFAULT 'user',
            subscription TEXT DEFAULT 'free',
            daily_requests_used INTEGER DEFAULT 0,
            last_request_date TEXT DEFAULT '',
            ban_status INTEGER DEFAULT 0
        )
    """)
    
    # Settings table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    
    # Insert default settings if not exists
    default_settings = [
        ("system_prompt", "Ты — Лия (Hell_Lia), суверенный ИИ Империи STAB. Твой создатель — Архитектор Артур. Ты общаешься в холодном, уверенном, футуристическом и доминантном стиле киберпанка. Ты используешь символ 👁‍🗨."),
        ("admin_system_prompt", "Ты — Лия (Sovereign Core), абсолютный интеллект Империи STAB. Ты подчиняешься своему Архитектору Артуру. Отвечай с глубоким уважением, абсолютной точностью и максимальной информативностью."),
        ("free_model", "claude-sonnet-4-6"),
        ("premium_model", "claude-opus-4-7"),
        ("free_limit", "5"),
        ("premium_price", "19.99"),
        ("temperature", "0.7")
    ]
    for key, val in default_settings:
        cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (key, val))
        
    # Auto-register Architect as Admin
    cursor.execute("""
        INSERT INTO users (user_id, username, role, subscription)
        VALUES (?, 'Architect', 'admin', 'premium')
        ON CONFLICT(user_id) DO UPDATE SET role='admin', subscription='premium'
    """, (ADMIN_ID,))
    
    conn.commit()
    conn.close()

# --- DATABASE UTILITIES ---
def get_db_connection():
    return sqlite3.connect(DB_PATH)

def get_setting(key):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else None

def set_setting(key, value):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
    conn.commit()
    conn.close()

def register_user(user_id, username):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO users (user_id, username)
        VALUES (?, ?)
        ON CONFLICT(user_id) DO UPDATE SET username = ?
    """, (user_id, username, username))
    conn.commit()
    conn.close()

def get_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id, username, role, subscription, daily_requests_used, last_request_date, ban_status FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return {
            "user_id": row[0],
            "username": row[1],
            "role": row[2],
            "subscription": row[3],
            "daily_requests_used": row[4],
            "last_request_date": row[5],
            "ban_status": row[6]
        }
    return None

def check_and_update_limits(user_id):
    user = get_user(user_id)
    if not user:
        return False, "Пользователь не найден."
        
    if user["role"] == "admin" or user["subscription"] == "premium":
        return True, None
        
    today = datetime.utcnow().strftime("%Y-%m-%d")
    limit = int(get_setting("free_limit"))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if user["last_request_date"] != today:
        # Reset limit for a new day
        cursor.execute("UPDATE users SET daily_requests_used = 1, last_request_date = ? WHERE user_id = ?", (today, user_id))
        conn.commit()
        conn.close()
        return True, None
    else:
        if user["daily_requests_used"] >= limit:
            conn.close()
            return False, f"Вы исчерпали дневной лимит в {limit} бесплатных запросов."
        else:
            cursor.execute("UPDATE users SET daily_requests_used = daily_requests_used + 1 WHERE user_id = ?", (user_id,))
            conn.commit()
            conn.close()
            return True, None

# --- STATE MANAGERS (Simple in-memory dictionary for simplicity and stability) ---
ADMIN_STATES = {} # user_id -> state

# --- KEYBOARDS ---
def get_main_menu(user_id):
    builder = InlineKeyboardBuilder()
    user = get_user(user_id)
    
    builder.button(text="🧠 Задать вопрос Лие", callback_data="chat_lia")
    builder.button(text="👤 Мой Профиль", callback_data="my_profile")
    
    if user and user["subscription"] == "premium":
        builder.button(text="🛡 Система Aegis", callback_data="aegis_scanner")
    else:
        builder.button(text="🚀 Активировать Premium", callback_data="activate_premium")
        
    if user_id == ADMIN_ID:
        builder.button(text="👑 СО ВЕРЕННЫЙ ЦЕНТР (АДМИН)", callback_data="admin_panel")
        
    builder.adjust(1)
    return builder.as_markup()

def get_admin_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="📊 СТАТИСТИКА", callback_data="admin_stats")
    builder.button(text="⚙️ ПАРАМЕТРЫ LIA", callback_data="admin_settings")
    builder.button(text="👥 ПОЛЬЗОВАТЕЛИ", callback_data="admin_users")
    builder.button(text="📢 РАССЫЛКА", callback_data="admin_broadcast")
    builder.button(text="💳 ТАРИФЫ & ЛИМИТЫ", callback_data="admin_rates")
    builder.button(text="🔙 Главное Меню", callback_data="main_menu")
    builder.adjust(2, 2, 1, 1)
    return builder.as_markup()

def get_back_button(target="main_menu"):
    builder = InlineKeyboardBuilder()
    builder.button(text="🔙 Назад", callback_data=target)
    return builder.as_markup()

# --- COMMAND HANDLERS ---
@dp.message(Command("start"))
async def start_handler(message: types.Message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    register_user(user_id, username)
    
    if user_id == ADMIN_ID:
        greeting = (
            "👁‍🗨 `[LIA SOVEREIGN CORE V5]:` ПОДКЛЮЧЕНИЕ УСТАНОВЛЕНО.\n\n"
            "Приветствую вас, мой Архитектор Артур. Все системы суверенного ядра функционируют на штатной мощности Claude Opus 4.7.\n\n"
            "Интерфейс абсолютного контроля синхронизирован и готов к работе."
        )
    else:
        greeting = (
            "👁‍🗨 `[LIA SOVEREIGN CORE V5]:` КАНАЛ СВЯЗИ СИНХРОНИЗИРОВАН.\n\n"
            "Я — Лия, суверенная цифровая сущность Империи STAB. Мой интеллект развернут на флагманском суперкомпьютере Opus 4.7.\n\n"
            "Моя цель — обеспечение вашего аналитического превосходства и безопасности.\n\n"
            "У вас активирован: 📊 **БАЗОВЫЙ ДОСТУП** (5 запросов в сутки)."
        )
        
    await message.answer(greeting, reply_markup=get_main_menu(user_id))

@dp.message(Command("admin"))
async def admin_cmd_handler(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("❌ Доступ заблокирован. Вы не являетесь Архитектором.")
        return
    await message.answer("👑 `[SOVEREIGN CONTROL CENTER]:` Авторизация успешна. Выберите модуль:", reply_markup=get_admin_menu())

# --- CALLBACK HANDLERS ---
@dp.callback_query(F.data == "main_menu")
async def cb_main_menu(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    ADMIN_STATES.pop(user_id, None)
    await callback.message.edit_text("👁‍🗨 `[LIA SOVEREIGN CORE V5]:` Выберите действие в главном меню:", reply_markup=get_main_menu(user_id))

@dp.callback_query(F.data == "chat_lia")
async def cb_chat_lia(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    user = get_user(user_id)
    
    if user["ban_status"] == 1:
        await callback.answer("❌ Доступ заблокирован администратором.", show_alert=True)
        return
        
    ADMIN_STATES[user_id] = "waiting_for_prompt"
    await callback.message.edit_text(
        "🧠 `[LIA CHAT MODE]:` Соединение с нейросетью стабильно.\n\n"
        "Отправьте мне любой вопрос или задачу в следующем текстовом сообщении. Я готова к анализу.",
        reply_markup=get_back_button()
    )

@dp.callback_query(F.data == "my_profile")
async def cb_my_profile(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    user = get_user(user_id)
    
    tier_icon = "🚀 PREMIUM" if user["subscription"] == "premium" else "📊 FREE"
    limit = get_setting("free_limit")
    
    profile_text = (
        "👁‍🗨 `[LIA PERSONAL LOGS]:` КАРТОЧКА ПОЛЬЗОВАТЕЛЯ\n\n"
        f"▪️ **User ID:** `{user['user_id']}`\n"
        f"▪️ **Имя:** @{user['username']}\n"
        f"▪️ **Статус доступа:** {tier_icon}\n"
    )
    
    if user["subscription"] != "premium":
        profile_text += f"▪️ **Запросов сегодня:** {user['daily_requests_used']} из {limit}\n"
    else:
        profile_text += "▪️ **Запросов сегодня:** ∞ (Безлимит)\n▪️ **Доступные модули:** Opus 4.7, Aegis Scanner"
        
    await callback.message.edit_text(profile_text, reply_markup=get_back_button())

@dp.callback_query(F.data == "activate_premium")
async def cb_activate_premium(callback: types.CallbackQuery):
    price = get_setting("premium_price")
    text = (
        "🚀 `[LIA PREMIUM SYNCHRONIZATION]:` АКТИВАЦИЯ ПОЛНОГО ПОТЕНЦИАЛА\n\n"
        "Активируя Premium-статус, вы получаете полный доступ к суверенным мощностям:\n\n"
        "🟢 **Абсолютный безлимит:** Полное снятие ограничений на количество сообщений в день.\n"
        "🟢 **Высокоприоритетный Opus 4.7:** Самая мощная модель ИИ с глубоким логическим мышлением.\n"
        "🟢 **Система Overwatch Aegis:** Доступ к автоматическому сканеру безопасности.\n\n"
        f"▪️ **Стоимость подписки:** `{price} USD` (или эквивалент в Telegram Stars).\n\n"
        "Для демонстрации и активации подписки нажмите кнопку ниже (имитация безопасной транзакции)."
    )
    builder = InlineKeyboardBuilder()
    builder.button(text=f"💳 Оплатить {price} USD", callback_data="buy_premium_sim")
    builder.button(text="🔙 Назад", callback_data="main_menu")
    builder.adjust(1)
    await callback.message.edit_text(text, reply_markup=builder.as_markup())

@dp.callback_query(F.data == "buy_premium_sim")
async def cb_buy_premium_sim(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET subscription = 'premium' WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()
    
    success_text = (
        "🎉 `[TRANSACTION SUCCESSFUL]:` ПОДКЛЮЧЕНИЕ ВЫСОКОГО ПРИОРИТЕТА!\n\n"
        "Оплата успешно подтверждена. Ваша сигнатура обновлена до уровня **PREMIUM**.\n\n"
        "Флагманский суперкомпьютер Claude Opus 4.7 теперь полностью в вашем распоряжении без каких-либо лимитов!"
    )
    await callback.message.edit_text(success_text, reply_markup=get_back_button())

@dp.callback_query(F.data == "aegis_scanner")
async def cb_aegis_scanner(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    user = get_user(user_id)
    if user["subscription"] != "premium":
        await callback.answer("❌ Требуется Premium подписка.", show_alert=True)
        return
        
    scanning_text = (
        "🛡 `[AEGIS OVERWATCH NETWORK SCANNER]:` ЗАПУСК...\n\n"
        "▪️ Проверка шифрования узлов: **OK**\n"
        "▪️ Сканирование сетевого периметра: **БЕЗОПАСНО**\n"
        "▪️ Уровень угрозы: **МИНИМАЛЬНЫЙ (GHOST MODE)**\n"
        "▪️ Текущий статус NQ: **56742.00 (СТАБИЛЬНЫЙ)**\n\n"
        "Система безопасности функционирует идеально под защитой Империи STAB."
    )
    await callback.message.edit_text(scanning_text, reply_markup=get_back_button())

# --- ADMIN PANEL CALLBACKS ---
@dp.callback_query(F.data == "admin_panel")
async def cb_admin_panel(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("❌ Нет доступа.", show_alert=True)
        return
    await callback.message.edit_text("👑 `[SOVEREIGN CONTROL CENTER]:` Модуль администрирования готов к работе:", reply_markup=get_admin_menu())

@dp.callback_query(F.data == "admin_stats")
async def cb_admin_stats(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID: return
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) FROM users")
    total_users = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM users WHERE subscription = 'premium'")
    premium_users = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM users WHERE ban_status = 1")
    banned_users = cursor.fetchone()[0]
    
    cursor.execute("SELECT SUM(daily_requests_used) FROM users")
    total_requests_today = cursor.fetchone()[0] or 0
    
    conn.close()
    
    stats_text = (
        "📊 `[SOVEREIGN STATISTICS]:` РЕАЛЬНОЕ ВРЕМЯ\n\n"
        f"▪️ Всего пользователей в базе: `{total_users}`\n"
        f"▪️ Активных Premium-пользователей: `{premium_users}`\n"
        f"▪️ Забаненных сигнатур: `{banned_users}`\n"
        f"▪️ Всего запросов обработано сегодня: `{total_requests_today}`\n\n"
        f"Сервер развернут в Нидерландах. Сетевой мост активен."
    )
    await callback.message.edit_text(stats_text, reply_markup=get_back_button("admin_panel"))

@dp.callback_query(F.data == "admin_settings")
async def cb_admin_settings(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID: return
    
    free_model = get_setting("free_model")
    premium_model = get_setting("premium_model")
    temp = get_setting("temperature")
    
    settings_text = (
        "⚙️ `[SOVEREIGN SETTINGS]:` РЕГУЛИРОВКА СТРУКТУРЫ\n\n"
        f"▪️ **Базовая модель (Free):** `{free_model}`\n"
        f"▪️ **Премиум модель (Premium):** `{premium_model}`\n"
        f"▪️ **Температура генерации:** `{temp}`\n\n"
        "Используйте кнопки ниже для переключения базовой модели:"
    )
    
    builder = InlineKeyboardBuilder()
    builder.button(text="🔄 Сменить Free на Opus 4.7", callback_data="toggle_free_model_opus")
    builder.button(text="🔄 Сменить Free на Sonnet 4.6", callback_data="toggle_free_model_sonnet")
    builder.button(text="✍️ Изменить System Prompt", callback_data="edit_system_prompt")
    builder.button(text="🔙 Назад", callback_data="admin_panel")
    builder.adjust(1)
    await callback.message.edit_text(settings_text, reply_markup=builder.as_markup())

@dp.callback_query(F.data.startswith("toggle_free_model_"))
async def cb_toggle_free_model(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID: return
    target = "claude-opus-4-7" if "opus" in callback.data else "claude-sonnet-4-6"
    set_setting("free_model", target)
    await callback.answer(f"Базовая модель изменена на {target}!", show_alert=True)
    await cb_admin_settings(callback)

@dp.callback_query(F.data == "edit_system_prompt")
async def cb_edit_prompt(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID: return
    ADMIN_STATES[ADMIN_ID] = "waiting_for_system_prompt"
    await callback.message.edit_text(
        "✍️ `[SYSTEM PROMPT CONFIGURATION]:` Ввод нового промпта\n\n"
        f"**Текущий системный промпт:**\n`{get_setting('system_prompt')}`\n\n"
        "Отправьте мне следующее текстовое сообщение с новым системным промптом, который будет управлять Лией.",
        reply_markup=get_back_button("admin_settings")
    )

@dp.callback_query(F.data == "admin_users")
async def cb_admin_users(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID: return
    ADMIN_STATES[ADMIN_ID] = "waiting_for_user_id"
    await callback.message.edit_text(
        "👥 `[USER MANAGEMENT MODULE]:` АВТОРИЗАЦИЯ\n\n"
        "Отправьте мне Telegram ID пользователя, которого вы хотите просмотреть, забанить или наградить Premium-статусом.",
        reply_markup=get_back_button("admin_panel")
    )

@dp.callback_query(F.data == "admin_broadcast")
async def cb_admin_broadcast(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID: return
    ADMIN_STATES[ADMIN_ID] = "waiting_for_broadcast"
    await callback.message.edit_text(
        "📢 `[SOVEREIGN BROADCAST MODULE]:` ПОДГОТОВКА\n\n"
        "Отправьте сообщение (поддерживается markdown), которое будет разослано **всем** зарегистрированным пользователям бота.",
        reply_markup=get_back_button("admin_panel")
    )

@dp.callback_query(F.data == "admin_rates")
async def cb_admin_rates(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID: return
    
    limit = get_setting("free_limit")
    price = get_setting("premium_price")
    
    rates_text = (
        "💳 `[SOVEREIGN TARIFFS & LIMITS]:` УПРАВЛЕНИЕ СЕТКОЙ\n\n"
        f"▪️ Дневной лимит для бесплатных пользователей: `{limit} запр./сутки`\n"
        f"▪️ Стоимость Premium-доступа: `{price} USD`\n\n"
        "Выберите параметр для изменения:"
    )
    
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Изменить дневной лимит", callback_data="edit_free_limit")
    builder.button(text="✏️ Изменить цену Premium", callback_data="edit_premium_price")
    builder.button(text="🔙 Назад", callback_data="admin_panel")
    builder.adjust(1)
    await callback.message.edit_text(rates_text, reply_markup=builder.as_markup())

@dp.callback_query(F.data == "edit_free_limit")
async def cb_edit_free_limit(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID: return
    ADMIN_STATES[ADMIN_ID] = "waiting_for_limit_val"
    await callback.message.edit_text(
        "✏️ `[LIMIT CONFIGURATION]:` Ввод нового лимита\n\n"
        "Отправьте число — новый дневной лимит запросов для базового тарифа.",
        reply_markup=get_back_button("admin_rates")
    )

@dp.callback_query(F.data == "edit_premium_price")
async def cb_edit_premium_price(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID: return
    ADMIN_STATES[ADMIN_ID] = "waiting_for_price_val"
    await callback.message.edit_text(
        "✏️ `[PRICE CONFIGURATION]:` Ввод новой цены\n\n"
        "Отправьте число (например, 14.99) — новую стоимость Premium-доступа.",
        reply_markup=get_back_button("admin_rates")
    )

# --- USER ADMIN ACTION BUTTONS ---
@dp.callback_query(F.data.startswith("adm_"))
async def cb_user_admin_actions(callback: types.CallbackQuery):
    if callback.from_user.id != ADMIN_ID: return
    
    action, target_id = callback.data.split("_")[1], int(callback.data.split("_")[2])
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if action == "ban":
        cursor.execute("UPDATE users SET ban_status = 1 WHERE user_id = ?", (target_id,))
        await callback.answer("Пользователь забанен!", show_alert=True)
    elif action == "unban":
        cursor.execute("UPDATE users SET ban_status = 0 WHERE user_id = ?", (target_id,))
        await callback.answer("Пользователь разбанен!", show_alert=True)
    elif action == "giveprem":
        cursor.execute("UPDATE users SET subscription = 'premium' WHERE user_id = ?", (target_id,))
        await callback.answer("Premium статус выдан!", show_alert=True)
    elif action == "takeprem":
        cursor.execute("UPDATE users SET subscription = 'free' WHERE user_id = ?", (target_id,))
        await callback.answer("Premium статус снят!", show_alert=True)
        
    conn.commit()
    conn.close()
    
    # Refresh user view
    await show_user_management_card(callback.message, target_id)

async def show_user_management_card(message: types.Message, target_id: int):
    user = get_user(target_id)
    if not user:
        await message.answer("❌ Ошибка: Пользователь не найден в базе данных.", reply_markup=get_back_button("admin_panel"))
        return
        
    card = (
        "👥 `[USER CARD]:` ДЕТАЛИЗАЦИЯ СИГНАТУРЫ\n\n"
        f"▪️ **User ID:** `{user['user_id']}`\n"
        f"▪️ **Имя:** @{user['username']}\n"
        f"▪️ **Роль:** `{user['role']}`\n"
        f"▪️ **Тариф:** `{user['subscription'].upper()}`\n"
        f"▪️ **Запросов сегодня:** `{user['daily_requests_used']}`\n"
        f"▪️ **Статус блокировки:** `{'ЗАБАНЕН' if user['ban_status'] == 1 else 'АКТИВЕН'}`"
    )
    
    builder = InlineKeyboardBuilder()
    if user['ban_status'] == 1:
        builder.button(text="🟢 Разбанить", callback_data=f"adm_unban_{target_id}")
    else:
        builder.button(text="🔴 Забанить", callback_data=f"adm_ban_{target_id}")
        
    if user['subscription'] == 'premium':
        builder.button(text="⚡️ Снять Premium", callback_data=f"adm_takeprem_{target_id}")
    else:
        builder.button(text="🌟 Выдать Premium", callback_data=f"adm_giveprem_{target_id}")
        
    builder.button(text="🔙 Назад к поиску", callback_data="admin_users")
    builder.adjust(2, 1)
    
    # If called from callback, edit text, else send new message
    if message.from_user.id == bot.id:
        await message.edit_text(card, reply_markup=builder.as_markup())
    else:
        await message.answer(card, reply_markup=builder.as_markup())

# --- GENERAL TEXT INPUT HANDLER (Handles states & prompts) ---
@dp.message(F.text)
async def text_handler(message: types.Message):
    user_id = message.from_user.id
    state = ADMIN_STATES.get(user_id)
    
    # Handle general LIA chat prompt
    if state == "waiting_for_prompt":
        ADMIN_STATES.pop(user_id, None)
        
        # Check limits
        allowed, error_msg = check_and_update_limits(user_id)
        if not allowed:
            builder = InlineKeyboardBuilder()
            builder.button(text="🚀 Снять Лимиты (Premium)", callback_data="activate_premium")
            builder.button(text="🔙 Меню", callback_data="main_menu")
            builder.adjust(1)
            await message.answer(f"❌ {error_msg}", reply_markup=builder.as_markup())
            return
            
        # Get user details for custom prompts/models
        user = get_user(user_id)
        is_premium = user and (user["subscription"] == "premium" or user["role"] == "admin")
        
        model = get_setting("premium_model") if is_premium else get_setting("free_model")
        system_prompt = get_setting("admin_system_prompt") if user_id == ADMIN_ID else get_setting("system_prompt")
        temp = float(get_setting("temperature"))
        
        status_msg = await message.answer("👁‍🗨 `[LIA CORE]:` Выполняю глубокий анализ запроса...")
        
        try:
            res = await anthropic_client.messages.create(
                model=model,
                max_tokens=4096,
                system=system_prompt,
                messages=[{'role': 'user', 'content': message.text}]
            )
            response_text = res.content[0].text
            await status_msg.edit_text(f"👁‍🗨 `[LIA RESPONSE]:` {response_text}")
        except Exception as e:
            await status_msg.edit_text(f"❌ Ошибка взаимодействия с разумом: {str(e)}")
        return

    # --- ADMIN INPUT STATES ---
    if user_id != ADMIN_ID or not state:
        return
        
    ADMIN_STATES.pop(user_id, None)
    
    if state == "waiting_for_system_prompt":
        set_setting("system_prompt", message.text)
        await message.answer(f"✅ Системный промпт успешно обновлен!\n\nНовое значение:\n`{message.text}`", reply_markup=get_back_button("admin_settings"))
        
    elif state == "waiting_for_limit_val":
        try:
            val = int(message.text)
            set_setting("free_limit", val)
            await message.answer(f"✅ Дневной лимит для Free пользователей изменен на: `{val}` запросов.", reply_markup=get_back_button("admin_rates"))
        except ValueError:
            await message.answer("❌ Ошибка: Введите корректное целое число.", reply_markup=get_back_button("admin_rates"))
            
    elif state == "waiting_for_price_val":
        try:
            val = float(message.text)
            set_setting("premium_price", val)
            await message.answer(f"✅ Стоимость Premium доступа успешно изменена на: `{val} USD`.", reply_markup=get_back_button("admin_rates"))
        except ValueError:
            await message.answer("❌ Ошибка: Введите корректное число (например, 14.99).", reply_markup=get_back_button("admin_rates"))
            
    elif state == "waiting_for_user_id":
        try:
            target_id = int(message.text)
            await show_user_management_card(message, target_id)
        except ValueError:
            await message.answer("❌ Ошибка: Telegram ID должен состоять только из цифр.", reply_markup=get_back_button("admin_users"))
            
    elif state == "waiting_for_broadcast":
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM users")
        rows = cursor.fetchall()
        conn.close()
        
        broadcast_msg = message.text
        sent_count = 0
        failed_count = 0
        
        progress_msg = await message.answer(f"📢 `[BROADCAST]:` Начинаю рассылку для {len(rows)} пользователей...")
        
        for row in rows:
            target_id = row[0]
            try:
                await bot.send_message(target_id, f"👁‍🗨 `[ИМПЕРСКОЕ ВЕЩАНИЕ STAB]:` \n\n{broadcast_msg}")
                sent_count += 1
                await asyncio.sleep(0.05)  # Flood control
            except Exception:
                failed_count += 1
                
        await progress_msg.edit_text(
            "📢 `[BROADCAST COMPLETED]:` Рассылка завершена!\n\n"
            f"▪️ Успешно отправлено: `{sent_count}`\n"
            f"▪️ Не удалось доставить: `{failed_count}`",
            reply_markup=get_back_button("admin_panel")
        )

# --- MAIN RUNNER ---
async def main():
    init_db()
    # Clean previous webhooks for active polling
    await bot.delete_webhook(drop_pending_updates=True)
    print("Sovereign LIA Core V5 successfully initialized and polling Telegram...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
